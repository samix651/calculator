﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            ConsoleKeyInfo opcion;
            do
            {





                Console.Clear();
                Console.BackgroundColor = ConsoleColor.DarkBlue;
                Console.ForegroundColor = ConsoleColor.White;
                Console.Clear();
                Console.WriteLine("bienvenido a calculator");
                Console.WriteLine("                                        ");
                Console.WriteLine("pulsa cualquier tecla para continuar");
                System.Console.ReadKey();
                Console.WriteLine("--==               menu                 =--");
                Console.WriteLine("                                           ");
                Console.WriteLine("Calcular edad...............................1");
                Console.WriteLine("calculadora normal y corriente..............2");
          opcion = Console.ReadKey();

                if (opcion.KeyChar == '1')
                {
                    Calcularedad();

                }
                if (opcion.KeyChar == '2')
                {

                    Sumar();

                }

              Console.ReadKey();
            } while (opcion.KeyChar != 'x');


        }

        static void Sumar()
        {
            Console.Write("numero 1:");

            string aa = Console.ReadLine();
            Console.Write("numero2:");
            string bb = Console.ReadLine();
            double a = double.Parse(aa);
          double b = double.Parse(bb);
                
           
           double c = a + b;
            Console.WriteLine("la suma de {0} + {1} = {2}", a, b, c);


        }


        static void Calcularedad()
        {
            Console.WriteLine("calcular edad de forma epica");
            Console.Write("año de nacimiento");
            string aa = Console.ReadLine();
            int a = int.Parse(aa);
            int c = DateTime.Now.Year - a;
            Console.WriteLine("la edad es {0}",c);


        }


    }
}
